<p align="center">
<a href="https://www.noob-hackers.com/2020/10/mrphish-tool-for-hacking-accounts.html"><img title="Made in INDIA" src="https://img.shields.io/badge/MADE%20IN-INDIA-SCRIPT?colorA=%23ff8100&colorB=%23017e40&colorC=%23ff0000&style=for-the-badge"></a>
</p>
<p align="center">
<a href="https://www.noob-hackers.com/2020/10/mrphish-tool-for-hacking-accounts.html"><img title="Made in INDIA" src="https://img.shields.io/badge/Tool-Vanish-green.svg"></a>
<a href="https://www.noob-hackers.com/2020/10/mrphish-tool-for-hacking-accounts.html"><img title="Version" src="https://img.shields.io/badge/Version-1.0-green.svg?style=flat-square"></a>
<a href="https://www.noob-hackers.com/2020/10/mrphish-tool-for-hacking-accounts.html"><img title="Maintainence" src="https://img.shields.io/badge/Maintained%3F-yes-green.svg"></a>
</p>
<p align="center">
<a href="https://www.noob-hackers.com/2020/10/mrphish-tool-for-hacking-accounts.html"><img title="mrphish" src="https://user-images.githubusercontent.com/49580304/102707183-9da9d480-424d-11eb-86c2-8b56a6c43fe0.jpg"></a>
</p>
<p align="center">
<a href="https://github.com/noob-hackers"><img title="Github" src="https://img.shields.io/badge/noob-hackers-brightgreen?style=for-the-badge&logo=github"></a>
<a href="https://rebrand.ly/noobhackers"><img title="YouTube" src="https://img.shields.io/badge/YouTube-Noob Hackers-red?style=for-the-badge&logo=Youtube"></a>
</p>
<p align="center">
<a href="https://github.com/noob-hackers"><img title="Language" src="https://img.shields.io/badge/Made%20with-Bash-1f425f.svg?v=103"></a>
<a href="https://github.com/noob-hackers"><img title="Followers" src="https://img.shields.io/github/followers/noob-hackers?color=blue&style=flat-square"></a>
<a href="https://github.com/noob-hackers"><img title="Stars" src="https://img.shields.io/github/stars/noob-hackers/vanish?color=red&style=flat-square"></a>
<a href="https://github.com/noob-hackers"><img title="Forks" src="https://img.shields.io/github/forks/noob-hackers/vanish?color=red&style=flat-square"></a>
<a href="https://github.com/noob-hackers"><img title="Watching" src="https://img.shields.io/github/watchers/noob-hackers/vanish?label=Watchers&color=blue&style=flat-square"></a>
<a href="https://github.com/noob-hackers"><img title="Licence" src="https://img.shields.io/badge/License-MIT-blue.svg"></a>
</p>

## ABOUT TOOL :

Vanish is a bash based script which is officially made for creating all os based virus and malware which destroys victims computer or any gadget. This tool works on both rooted Android device and Non-rooted Android device.

## AVAILABLE ON :

* Termux

### TESTED ON :

* Termux
* Kali Linux
* other linux distributions as well

### REQUIREMENTS :
* internet 5MB
* Basic packages
* storage 10MB

## FEATURES :
* [+] Dangerous viruses !
* [+] Updated maintainence !
* [+] Updated response !
* [+] No link issues !

## INSTALLATION [Termux] :

* `apt-get update -y`
* `apt-get upgrade -y`
* `pkg install python -y`
* `pkg install python2 -y`
* `pkg install git -y`
* `pip install lolcat`
* `git clone https://github.com/noob-hackers/vanish`
* `cd $HOME`
* `ls`
* `cd vanish`
* `ls`
* `bash setup`
* `bash vanish`
```
[+]-- We dont hold any reponsibility if you face any data loss
[+]-- Dont open any virus or malware on your computer ....
```
## USAGE OPTIONS [Termux] :

__VANISH DEVICE__ :
- From this option you can create virus/malware for any os.

__SAVE DEVICE__ :
- From this option you can save infected android device.

__ABOUT__ :
- From this option you can know more about author.

__UPDATE__ :
- From this option you can update vanish tool if updates are available for that.

__SUBSCRIBE__ :
- From this option you can easily subscribe our official channel.

__EXIT__ :
- From this option you can exit from tool 

## SCREEN SHOTS [Termux]

<br>
<p align="center">
<img width="50%" src="https://user-images.githubusercontent.com/49580304/102707181-9b477a80-424d-11eb-8606-e91b13c86849.jpg"/>
<img width="50%" src="https://user-images.githubusercontent.com/49580304/102707182-9d113e00-424d-11eb-8ace-7816912f1b79.jpg"/>
</p>

## WATCH VIDEO [Termux]

[![des](https://user-images.githubusercontent.com/49580304/96466915-3c2ea080-11df-11eb-8328-100ca165c12c.jpg)](https://rebrand.ly/rcentvideo)

## CONNECT WITH US :

[![Messenger](https://img.shields.io/badge/Chat-Messenger-blue?style=for-the-badge&logo=messenger)](https://rebrand.ly/fbmsnger)
<a href="https://rebrand.ly/githubprof"><img title="Github" src="https://img.shields.io/badge/noob-hackers-brightgreen?style=for-the-badge&logo=github"></a>
[![Instagram](https://img.shields.io/badge/INSTAGRAM-FOLLOW-red?style=for-the-badge&logo=instagram)](https://rebrand.ly/insgrm)
[![Instagram](https://img.shields.io/badge/WEBSITE-VISIT-yellow?style=for-the-badge&logo=blogger)](https://rebrand.ly/noobwebs)
[![Instagram](https://img.shields.io/badge/LINKEDIN-CONNECT-red?style=for-the-badge&logo=linkedin)](https://rebrand.ly/linkedinprof)
[![Instagram](https://img.shields.io/badge/FACEBOOK-LIKE-red?style=for-the-badge&logo=facebook)](https://rebrand.ly/fsbpage)
[![Instagram](https://img.shields.io/badge/TELEGRAM-CHANNEL-red?style=for-the-badge&logo=telegram)](https://rebrand.ly/telegramchnl)
[![Instagram](https://img.shields.io/badge/WHATSAPP-JOINGROUP-red?style=for-the-badge&logo=whatsapp)](https://rebrand.ly/hckrgroups)
<a href="https://rebrand.ly/noobhackers"><img title="YouTube" src="https://img.shields.io/badge/YouTube-Noob Hackers-red?style=for-the-badge&logo=Youtube"></a>

## BUY ME A COFFEE :

<p align="center">
<a href="https://rebrand.ly/BuyCoffee"><img title="Noob Hackers" src="https://camo.githubusercontent.com/ae8af018f80649f3d379eb23dbf59acceaffa24e/68747470733a2f2f6c69626572617061792e636f6d2f6173736574732f776964676574732f646f6e6174652e737667"></a>
</p>

## WARNING : 
***This tool is only for educational purpose. If you use this tool for other purposes except education we will not be responsible in such cases.***
